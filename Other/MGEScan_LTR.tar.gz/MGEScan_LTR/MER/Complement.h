#ifndef __COMPLEMENT_H__
#define __COMPLEMENT_H__

class Sequence;

class Complement
{
	public:
		static Sequence* com(Sequence* seq);
		static char com(char base);
};


#endif // __COMPLEMENT_H__

