#include "lib.h"
#include "Position2D.h"

int Position2D::m_dim = 2;

