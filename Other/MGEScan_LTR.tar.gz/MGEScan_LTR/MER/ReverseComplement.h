#ifndef __REVERSE_COMPLEMENT_H__
#define __REVERSE_COMPLEMENT_H__

class Sequence;

class ReverseComplement
{
	public:
		static Sequence* rc(Sequence* seq);
};


#endif // __REVERSE_COMPLEMENT_H__

